To install the Dynamixel library:

1. Unzip the archive to a location outside of your Python installation.

2. Bring up a command prompt and cd into the dynamixel-installer directory.

3. Run the command "python setup.py install"

4. You can now use the library by doing an "import dynamixel".

5. For an example of how to use it, see the two sample files example.py and example2.py in
   the dynamixel-installer directory.
